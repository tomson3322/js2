var test, liczba;
test = 15;
liczba = 10;

	if ((test > 12) && (liczba > 5))
		{
			document.write("obie wieksze");
		}
		else
		{
			document.write("jedna lub dwie opcje mniejsze");
		}
		

