var liczba1, liczba2, liczba3, liczba4, liczba5,suma;
liczba1 = 1;
liczba2 = 2;
liczba3 = 3;
liczba4 = 5;
liczba5 = 5;
suma = liczba1+liczba2+liczba3+liczba4+liczba5;
document.write(liczba1+liczba2+liczba3+liczba4+liczba5, "<br />")
document.write(suma/5)

