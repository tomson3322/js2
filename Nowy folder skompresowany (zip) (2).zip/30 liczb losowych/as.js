var licznik,liczba=0, mala= 100, duza=0;

for (licznik=0; licznik < 30 ; licznik++ )
{
	
liczba = (Math.random() * 100);
liczba = Math.ceil(liczba);
document.write(liczba, "<br />");

	if	(liczba < mala)
		{
		mala=liczba;
		}
	
	if	(liczba > duza)
		{
		duza=liczba;
		}

}
document.write("<p>","najmniejsza: ",mala,"</p>");
document.write("<p>","najwieksza: ",duza,"</p>");


	

