var l1, l2, l3;

l1 = (Math.random() * 10);
l1 = Math.ceil(l1);
document.write(l1);




		

