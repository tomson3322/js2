var licznik,liczba=0;
for (licznik=200; licznik < 501 ; licznik++ )
{
liczba=liczba+licznik
document.write(liczba, "<br />")
}
