var liczba1, liczba2, suma;
liczba1 = 100;
liczba2 = 25;
suma = liczba1 + liczba2

document.write(suma, "<br />")

	if (suma > 0)
		{
			document.write("liczba jest wieksza od zera");
		}
		else
		{
			document.write("liczba jest mniejsza od zera");
		}