var liczba1, liczba2, liczba3;
liczba1 = 5;
liczba2 = 6;
liczba3 = 8;


	if ((liczba1 > liczba2) && (liczba1 > liczba3))
		{
			document.write ( liczba1, "<br />" ) ;
		}
	
	if ((liczba2 > liczba1) && (liczba2 > liczba3))
		{
			document.write ( liczba2, "<br />" ) ;
		}
		
	if ((liczba3 > liczba2) && (liczba3 > liczba1))
		{
			document.write ( liczba3, "<br />" ) ;
		}
		
	
		

			if (liczba1 == liczba2)
		{
			if (liczba1 == liczba3)
				{
				document.write("wszystkie liczby są takie same", "<br />")
				}
		}
				else
					if (liczba1 == liczba2)
						{
						document.write("liczba 1 i liczba 2 są takie same", "<br />")
						}
				else
					if (liczba1 == liczba3)
						{
						document.write("liczba 1 i liczba 3 są takie same", "<br />")
						}			
				else	
					if (liczba2 == liczba3)
						{
						document.write("liczba 2 i liczba 3 są takie same", "<br />")
						}	
			
		

	
	

		

			