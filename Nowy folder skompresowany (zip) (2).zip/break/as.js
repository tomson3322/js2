var licznik,liczba=0, mala= 100, duza=0;


for (licznik=0; licznik < 30 ; licznik++ )
{

document.write("zmienna: ", licznik, "<br />")

if (licznik == 5)
	{
	break
	}


}



