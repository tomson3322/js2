var  liczba, suma = 0, dana = 33;


for ( ; dana==33  ; )

{

liczba = prompt("podaj liczbe:","");

liczba = parseInt(liczba);


suma += liczba;
document.write(suma, "<br />");



if (liczba == 33)
	{
	document.write("<p>", suma,"</p>" );
	dana=0;
	}


}







