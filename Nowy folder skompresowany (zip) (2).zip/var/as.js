var tester;
	tester = 123;
	document.write( tester, "<br />" );
	
	tester += 12;
	document.write( tester, "<br />")
	
	tester --;
	document.write( tester, "<br />")
	
	tester = tester + 5;
	document.write( tester, "<br />")
	
	