var  liczba, liczba1;


liczba = prompt("podaj liczbe:","");
liczba = parseInt(liczba);

liczba1 = prompt("podaj liczbe:","");
liczba1 = parseInt(liczba1);

document.write("podane liczby: ","<p>",liczba,",",liczba1,"</p>");

if (liczba % 2)
{
	document.write(liczba + 1);


	
}
else
{
	document.write(liczba);
}

	for ( ; ; )
{
	liczba + 2
	document.write(liczba)
	
	if (liczba >= liczba1)
	{
		break
	}
}