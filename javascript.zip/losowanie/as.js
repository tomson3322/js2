var liczba;

liczba = (Math.random() * 10);
liczba = Math.ceil(liczba);
document.write(liczba);

if ( liczba % 2 == 0)
{
	document.write("<br /> liczba jest parzysta");
}	
else
{
	document.write("<br /> liczba nie jest parzysta");
}
