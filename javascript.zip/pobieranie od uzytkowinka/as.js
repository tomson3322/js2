var liczba1 = prompt("podaj liczbe:","");
var liczba2 = prompt("podaj liczbe:","");
var liczba3 = prompt("podaj liczbe:","");

liczba1 = parseInt(liczba1);
liczba2 = parseInt(liczba2);
liczba3 = parseInt(liczba3);

document.write("podane liczby: ",liczba1, ",", liczba2, ",", liczba3, "<br />")

	if ((liczba1 > liczba2) && (liczba1 > liczba3))
		{
			document.write ( "najwieksza liczba: ", liczba1, "<br />" ) ;
		}
	
	if ((liczba2 > liczba1) && (liczba2 > liczba3))
		{
			document.write ( "najwieksza liczba: ", liczba2, "<br />" ) ;
		}
		
	if ((liczba3 > liczba2) && (liczba3 > liczba1))
		{
			document.write ( "najwieksza liczba: ", liczba3, "<br />" ) ;
		}
		