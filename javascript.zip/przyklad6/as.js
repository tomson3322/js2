var liczba1 = prompt("podaj liczbe1:","")
var liczba2 = prompt("podaj liczbe2:","")

liczba1=parseInt(liczba1);
liczba2=parseInt(liczba2);

document.write("<p>podano liczbe1:</p>", liczba1,"<br />")
document.write("<p>podano liczbe2:</p>", liczba2,"<br />")

document.write("<p>suma liczb to:</p>", liczba1 + liczba2);