var licznik,liczba=0, mala= 100, duza=0;


for (licznik=1; licznik < 10 ; licznik++ )
{
	if (licznik == 4)
	{
	
		continue;
	}
document.write(licznik, "<br />")
}





