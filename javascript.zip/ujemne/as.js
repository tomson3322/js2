var licznik, l1=0, l2=0;


	//pętla
	for ( licznik = 0 ; licznik <= 25 ; licznik ++ )
	{

	l1 = (Math.random() * 10);
	l1 = Math.ceil(l1);	
	document.write(l1, "<br />")
	
	l2 = (Math.random() * -10);
	l2 = Math.floor(l2);	
	document.write("<span style='color:#2DD40F;'>",l2,"</span>","<br />")
	

	}