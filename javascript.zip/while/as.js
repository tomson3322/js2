var licznik=0,liczba=0, mala= 100, duza=0;


while (licznik < 100)
{
	licznik++
	document.write(licznik, "<br />")
}



