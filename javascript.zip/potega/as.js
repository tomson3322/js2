var liczbaA,liczbaB,stala;


liczbaA=prompt("podaj liczbe","");
liczbaB=prompt("podaj potege","");
liczbaA = parseInt(liczbaA);
liczbaB = parseInt(liczbaB);

stala=liczbaA

for ( var i=1 ; i<liczbaB; i++)
{
	liczbaA=liczbaA*stala;
	
}
document.write(liczbaA);
