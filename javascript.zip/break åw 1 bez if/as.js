var  liczba, suma = 0, ileliczb = 0;

for ( ; liczba!=33  ; )
{
	liczba = prompt("podaj liczbe:","");

	liczba = parseInt(liczba);

	suma += liczba;
	
	document.write(suma, "<br />");
	
	ileliczb++
}

document.write("<p>","<br />","wprowadzono liczb: ", ileliczb, "</p>")
document.write("<p>", suma ,"</p>")