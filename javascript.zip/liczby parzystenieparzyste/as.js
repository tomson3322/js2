var licznik, l1=0;


	//pętla
	for ( licznik = 0 ; licznik <= 40 ; licznik ++ )
	{
	//generator
	l1 = (Math.random() * 1200);
	l1 = Math.ceil(l1);	

		
	//parzystość	
	if ((l1 % 2) == 0 )
		{
			document.write("<span style='color:blue;'>",l1,"</span>","<br />");
		}
	else
		{
			document.write("<span style='color:#2DD40F';>",l1,"</span>","<br />");
		}
	}