var  liczba, liczba1, licznik;


liczba = prompt("podaj liczbe:","");
liczba = parseInt(liczba);

liczba1 = prompt("podaj liczbe:","");
liczba1 = parseInt(liczba1);


document.write("podane liczby: ","<p>",liczba,",",liczba1,"</p>");



for ( licznik = liczba ; licznik <= liczba1 ; licznik ++ )
	{
		
	if ((licznik % 2) == 0 )
	{
	document.write(licznik, ",");
	}
	
	
		
	}
	