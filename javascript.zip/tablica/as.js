var suma = 0, tablica = [ 5, 6, 32, 312, 56, 994];

for (var licznik = 0 ; licznik < tablica.length ; licznik++)
{
suma += tablica[licznik];
}

document.write(suma, "<br />");

