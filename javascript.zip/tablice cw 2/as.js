var liczba, tablica=[], wiersz = 0;


for( var licznik=0; licznik<100; licznik++)
{
	
	liczba = (Math.random() * 10);
	liczba = Math.ceil(liczba);
	wiersz++


		 tablica[licznik] = liczba;
		
		if(tablica[licznik] % 2)
		{
			document.write("<span id='sposub2'>",tablica[licznik],",","</span>");
		}
		else{
			document.write("<span id='sposub2'>","X","</span>")
		}

	if(wiersz == 10){
		document.write("<br />")
		wiersz = 0
	}
	
}
