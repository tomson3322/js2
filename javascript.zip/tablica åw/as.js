var liczba, suma=0, suma1=0, tab=0, tablica=[];




for(var licznik = 0 ; licznik < 5 ; licznik++)
{
liczba=prompt("podaj liczbe","");
liczba = parseInt(liczba);


tablica[tab] = liczba

tab++



}
document.write("<span id='dwa'>")

for(var licz = 0 ; licz < tablica.length ; licz++)
{
	suma += tablica[licz];
	document.write(tablica[licz])
	if(licz == 4)
	{
	
	}
	else
	{
		document.write("+")
		
	}
	
}

document.write("</span>")
for(var liczn = 0 ; liczn < tablica.length ; liczn++)
{
	suma1 += tablica[liczn];
	
}
document.write("<span id='jeden'>", "=",suma,"</span>");